# SOAT10 – Video Service (Hexagonal + Protocol)

Suba com:
```
docker compose up --build
```
- API: http://localhost:8000/docs
- Flower: http://localhost:5555
- RabbitMQ: http://localhost:15672 (guest/guest)
