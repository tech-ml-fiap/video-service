from sqlalchemy.orm import declarative_base, mapped_column, Mapped
from sqlalchemy import String, Integer, Enum, DateTime, Text, Float, ForeignKey, func
from app.domain.entities import JobStatus

Base = declarative_base()

class VideoModel(Base):
    __tablename__ = "videos"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    storage_ref: Mapped[str] = mapped_column(Text)
    duration: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped = mapped_column(DateTime, server_default=func.now())

    def to_entity(self):
        from app.domain.entities import Video
        return Video(
            id=self.id, user_id=self.user_id, filename=self.filename,
            storage_ref=self.storage_ref, duration=self.duration, created_at=self.created_at
        )

    @staticmethod
    def from_entity(v):
        return VideoModel(
            id=v.id, user_id=v.user_id, filename=v.filename, storage_ref=v.storage_ref, duration=v.duration
        )

class JobModel(Base):
    __tablename__ = "video_jobs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    video_id: Mapped[str] = mapped_column(String(36), ForeignKey("videos.id"))
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    status: Mapped[JobStatus] = mapped_column(Enum(JobStatus), default=JobStatus.QUEUED, index=True)
    fps: Mapped[int] = mapped_column(Integer, default=1)
    frame_count: Mapped[int] = mapped_column(Integer, default=0)
    artifact_ref: Mapped[str | None] = mapped_column(Text, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped = mapped_column(DateTime, server_default=func.now(), index=True)
    updated_at: Mapped = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    def to_entity(self):
        from app.domain.entities import VideoJob
        return VideoJob(
            id=self.id, video_id=self.video_id, user_id=self.user_id, status=self.status, fps=self.fps,
            frame_count=self.frame_count, artifact_ref=self.artifact_ref, error=self.error,
            created_at=self.created_at, updated_at=self.updated_at
        )

    @staticmethod
    def from_entity(j):
        return JobModel(
            id=j.id, video_id=j.video_id, user_id=j.user_id, status=j.status, fps=j.fps,
            frame_count=j.frame_count, artifact_ref=j.artifact_ref, error=j.error
        )
