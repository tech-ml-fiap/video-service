import subprocess, glob, os
from app.domain.ports.video_processor import VideoProcessorPort

class FFmpegVideoProcessor(VideoProcessorPort):
    def extract_frames(self, input_path: str, out_dir: str, fps: int = 1) -> int:
        pattern = os.path.join(out_dir, "frame_%04d.png")
        cmd = ["ffmpeg", "-i", input_path, "-vf", f"fps={fps}", "-y", pattern]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "ffmpeg error")
        frames = glob.glob(os.path.join(out_dir, "frame_*.png"))
        return len(frames)
