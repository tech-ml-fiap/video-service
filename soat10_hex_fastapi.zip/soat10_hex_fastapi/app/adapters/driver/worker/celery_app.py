import os
from celery import Celery

broker_url = os.getenv("BROKER_URL", "amqp://guest:guest@localhost:5672//")
result_backend = os.getenv("RESULT_BACKEND", "rpc://")
celery_app = Celery("video_processor", broker=broker_url, backend=result_backend)
