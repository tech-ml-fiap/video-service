from fastapi import FastAPI
from app.adapters.driver.api.controllers import router as api_router

app = FastAPI(title="SOAT10 - Video Service (Hexagonal)", version="0.2.0")
app.include_router(api_router)
