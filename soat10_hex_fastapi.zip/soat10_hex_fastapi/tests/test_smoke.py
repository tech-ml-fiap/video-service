def test_ok(): assert 1+1==2
